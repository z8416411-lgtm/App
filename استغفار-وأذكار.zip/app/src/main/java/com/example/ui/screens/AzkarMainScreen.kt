package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material.ripple.rememberRipple
import java.util.Locale
import com.example.R
import com.example.data.model.CustomDhikr
import com.example.ui.model.DhikrCategory
import com.example.ui.model.DhikrData
import com.example.ui.model.DhikrStaticItem
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.DhikrViewModel
import com.example.ui.viewmodel.MainTab
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AzkarMainScreen(viewModel: DhikrViewModel) {
    // Force RTL local layout direction specifically for the Islamic Arabic branding
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
        val isSoundEnabled by viewModel.isSoundEnabled.collectAsStateWithLifecycle()
        val isVibrationEnabled by viewModel.isVibrationEnabled.collectAsStateWithLifecycle()
        val fontSize by viewModel.fontSizeFlow.collectAsStateWithLifecycle()
        val todayCount by viewModel.todayTotalCount.collectAsStateWithLifecycle()

        var showSettingsDialog by remember { mutableStateOf(false) }

        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "أذكار واستغفار",
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 21.sp
                            )
                            Text(
                                text = "ألا بذكر الله تطمئن القلوب",
                                color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.8f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Light
                            )
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { showSettingsDialog = true },
                            modifier = Modifier.testTag("settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "الإعدادات",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = MaterialTheme.colorScheme.onBackground
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    windowInsets = WindowInsets.navigationBars
                ) {
                    val items = listOf(
                        MainTab.AZKAR to "الأذكار",
                        MainTab.TASBIH to "السبحة",
                        MainTab.HISTORY to "الإحصائيات",
                        MainTab.BENEFITS to "فضائل"
                    )
                    val icons = listOf(
                        Icons.Default.Home,
                        Icons.Default.Refresh,
                        Icons.Default.Star,
                        Icons.Default.Info
                    )

                    items.forEachIndexed { index, (tab, label) ->
                        val selected = currentTab == tab
                        NavigationBarItem(
                            selected = selected,
                            onClick = { viewModel.switchTab(tab) },
                            icon = {
                                Icon(
                                    imageVector = icons[index],
                                    contentDescription = label,
                                    tint = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                                )
                            },
                            label = {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            val glowColor = MaterialTheme.colorScheme.secondary
            val borderColor = MaterialTheme.colorScheme.primary
            // Background ambient pattern
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .drawBehind {
                        // Soft geometric radial light representing spiritual glow
                        val colors = listOf(glowColor.copy(alpha = 0.04f), Color.Transparent)
                        drawCircle(
                            brush = Brush.radialGradient(colors, center = Offset(size.width / 2, size.height / 3)),
                            radius = size.width * 0.9f
                        )
                        // Elegant top borders
                        drawLine(
                            color = borderColor.copy(alpha = 0.15f),
                            start = Offset(0f, 0f),
                            end = Offset(size.width, 0f),
                            strokeWidth = 2f
                        )
                    }
            ) {
                AnimatedContent(
                    targetState = currentTab,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(180))
                    },
                    label = "TabTransition"
                ) { targetTab ->
                    when (targetTab) {
                        MainTab.AZKAR -> AzkarTabScreen(viewModel, fontSize)
                        MainTab.TASBIH -> TasbihTabScreen(viewModel, fontSize)
                        MainTab.HISTORY -> HistoryTabScreen(viewModel)
                        MainTab.BENEFITS -> BenefitsTabScreen(fontSize)
                    }
                }
            }
        }

        if (showSettingsDialog) {
            SettingsDialog(
                viewModel = viewModel,
                currentFontSize = fontSize,
                isSound = isSoundEnabled,
                isVibe = isVibrationEnabled,
                onDismiss = { showSettingsDialog = false }
            )
        }
    }
}

// ----------------------------------------------------
// TAB 1: DAILY AZKAR SCREEN
// ----------------------------------------------------
@Composable
fun AzkarTabScreen(viewModel: DhikrViewModel, fontSize: Float) {
    var selectedCategory by remember { mutableStateOf(DhikrCategory.MORNING) }
    var searchKeywords by remember { mutableStateOf("") }
    var isReaderMode by remember { mutableStateOf(true) } // Highlight the reader mode by default!

    val customDhikrs by viewModel.customDhikrs.collectAsStateWithLifecycle()

    val filteredItems = remember(selectedCategory, searchKeywords) {
        DhikrData.items.filter { it.category == selectedCategory }
            .filter { it.text.contains(searchKeywords, ignoreCase = true) || it.virtue.contains(searchKeywords, ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Search & Filter
        OutlinedTextField(
            value = searchKeywords,
            onValueChange = { searchKeywords = it },
            label = { Text("بحث في الأذكار...", fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp, bottom = 6.dp)
                .testTag("azkar_search_input"),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                unfocusedLabelColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
            )
        )

        // Mode selector row (List View vs Interactive Reader View)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "طريقة عرض الأذكار:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), RoundedCornerShape(10.dp))
                    .padding(2.dp)
            ) {
                // List Mode Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (!isReaderMode) MaterialTheme.colorScheme.primary else Color.Transparent)
                        .clickable { isReaderMode = false }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.List,
                            contentDescription = "عرض قائمة",
                            tint = if (!isReaderMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "عرض القائمة",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (!isReaderMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                        )
                    }
                }

                // Card Reader Mode Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isReaderMode) MaterialTheme.colorScheme.primary else Color.Transparent)
                        .clickable { isReaderMode = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "القارئ التفاعلي",
                            tint = if (isReaderMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "القارئ التفاعلي",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isReaderMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }

        // Categories Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DhikrCategory.values().forEach { cat ->
                val active = selectedCategory == cat
                FilterChip(
                    selected = active,
                    onClick = {
                        selectedCategory = cat
                        searchKeywords = ""
                    },
                    label = { Text(cat.arabicName, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                        containerColor = MaterialTheme.colorScheme.surface,
                        labelColor = MaterialTheme.colorScheme.primary
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
            }
        }

        if (!isReaderMode) {
            // Action resets
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${filteredItems.size} ذكراً متوفراً",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )

                TextButton(
                    onClick = {
                        viewModel.resetCategoryProgress(filteredItems)
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.secondary),
                    modifier = Modifier.testTag("reset_category_button")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إعادة تصفير القسم", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            // List of Cards
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 32.dp)
            ) {
                items(filteredItems, key = { it.id }) { item ->
                    StaticDhikrCard(item, viewModel, fontSize)
                }

                // Display Custom User Azkar also under ISTIGHFAR category to enrich the experience
                if (selectedCategory == DhikrCategory.ISTIGHFAR_TASBIH && customDhikrs.isNotEmpty()) {
                    item {
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 16.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
                        )
                        Text(
                            text = "أذكاري المخصصة",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 16.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    items(customDhikrs) { custom ->
                        CustomDhikrItemCard(custom, viewModel, fontSize)
                    }
                }
            }
        } else {
            // Beautiful interactive central reader focused on high visibility and smooth traversing
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(bottom = 16.dp)
            ) {
                InteractiveDhikrReader(
                    items = filteredItems,
                    viewModel = viewModel,
                    fontSize = fontSize
                )
            }
        }
    }
}

@Composable
fun InteractiveDhikrReader(
    items: List<DhikrStaticItem>,
    viewModel: DhikrViewModel,
    fontSize: Float
) {
    if (items.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "لا توجد أذكار في هذا القسم تطابق التصفية. جرب كتابة كلمة أخرى في خانة البحث.",
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )
        }
        return
    }

    var currentIndex by remember(items) { mutableStateOf(0) }
    // Guard index to prevent out of bounds when search context alters items lists dynamically
    val safeIndex = currentIndex.coerceIn(0, items.size - 1)
    val currentItem = items[safeIndex]

    val remaining = viewModel.staticDhikrProgress[currentItem.id] ?: currentItem.count
    val isCompleted = remaining == 0
    val progressFraction = if (currentItem.count > 0) (currentItem.count - remaining).toFloat() / currentItem.count else 1f

    val view = LocalView.current
    val soundEnabled by viewModel.isSoundEnabled.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Navigation & Progress Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${safeIndex + 1} من ${items.size}",
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                fontSize = 13.sp
            )

            // Linear Progress indicating card browsing traversal progress
            LinearProgressIndicator(
                progress = { (safeIndex + 1).toFloat() / items.size },
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 14.dp)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
            )

            TextButton(
                onClick = {
                    viewModel.resetStaticDhikr(currentItem)
                },
                contentPadding = PaddingValues(horizontal = 8.dp),
                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.secondary)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("إعادة التكرار", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Main reading card containing the centered focal text
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clickable {
                    if (!isCompleted) {
                        if (soundEnabled) {
                            view.playSoundEffect(android.view.SoundEffectConstants.CLICK)
                        }
                        viewModel.decrementStaticDhikr(currentItem)
                    }
                },
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "تصنيف: ${currentItem.category.arabicName}",
                        color = MaterialTheme.colorScheme.secondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )

                    if (isCompleted) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "مكتمل",
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "تم بحمد الله",
                                color = MaterialTheme.colorScheme.tertiary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Text(
                            text = "التكرار المطلـوب: ${currentItem.count} مرّات",
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Mid scrollable block for the sacred content
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = currentItem.text,
                        fontSize = (fontSize + 1.5f).sp,
                        lineHeight = ((fontSize + 1.5f) * 1.55f).sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isCompleted) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f) else MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Beautiful circle Clicker representing progress of the current card
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .clip(CircleShape)
                        .background(
                            if (isCompleted) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f)
                            else MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                        )
                        .border(
                            1.5.dp,
                            if (isCompleted) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "تم",
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.size(40.dp)
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = remaining.toString(),
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "اضغط",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Tiny internal progress bar inside the card
                if (!isCompleted && progressFraction > 0f) {
                    Spacer(modifier = Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { progressFraction },
                        modifier = Modifier
                            .fillMaxWidth(0.75f)
                            .height(4.dp)
                            .clip(CircleShape),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Virtue / Meaning context helper box
        if (currentItem.virtue.isNotBlank() || currentItem.reference.isNotBlank()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.04f))
                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
                    .padding(12.dp)
            ) {
                Column {
                    if (currentItem.virtue.isNotBlank()) {
                        Text(
                            text = "فضل الذكر: ${currentItem.virtue}",
                            fontSize = 11.5.sp,
                            lineHeight = 17.sp,
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    if (currentItem.reference.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "[ المصدر: ${currentItem.reference} ]",
                            fontSize = 10.5.sp,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                            fontWeight = FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Left
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Navigation bottom row (Next / Previous buttons)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { if (safeIndex > 0) currentIndex-- },
                enabled = safeIndex > 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary,
                    disabledContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.2f),
                    disabledContentColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                ),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "السابق", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("الذكر السابق", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Button(
                onClick = { if (safeIndex < items.size - 1) currentIndex++ },
                enabled = safeIndex < items.size - 1,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    disabledContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.2f),
                    disabledContentColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
            ) {
                Text("الذكر التالي", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(6.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "التالي", modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun StaticDhikrCard(item: DhikrStaticItem, viewModel: DhikrViewModel, fontSize: Float) {
    val remaining = viewModel.staticDhikrProgress[item.id] ?: item.count
    val isCompleted = remaining == 0
    val progressFraction = if (item.count > 0) (item.count - remaining).toFloat() / item.count else 1f

    val view = LocalView.current
    val soundEnabled by viewModel.isSoundEnabled.collectAsStateWithLifecycle()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                if (!isCompleted) {
                    if (soundEnabled) {
                        view.playSoundEffect(android.view.SoundEffectConstants.CLICK)
                    }
                    viewModel.decrementStaticDhikr(item)
                }
            },
        colors = CardDefaults.cardColors(
            containerColor = if (isCompleted) MaterialTheme.colorScheme.surface.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            1.dp,
            if (isCompleted) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.4f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Done indicator
                if (isCompleted) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "مكتمل",
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "تم بحمد الله",
                            color = MaterialTheme.colorScheme.tertiary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Text(
                        text = "التكرار المطلـوب: ${item.count}",
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.9f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Mini counter circle
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            if (isCompleted) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.primary.copy(
                                alpha = 0.1f
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.size(16.dp)
                        )
                    } else {
                        Text(
                            text = remaining.toString(),
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Main Dhikr Text
            Text(
                text = item.text,
                fontSize = fontSize.sp,
                lineHeight = (fontSize * 1.5).sp,
                fontWeight = FontWeight.SemiBold,
                color = if (isCompleted) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f) else MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Right,
                modifier = Modifier.fillMaxWidth()
            )

            if (item.virtue.isNotBlank() || item.reference.isNotBlank()) {
                Spacer(modifier = Modifier.height(12.dp))
                // Clean expander/container for virtues
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.04f))
                        .padding(10.dp)
                ) {
                    Column {
                        if (item.virtue.isNotBlank()) {
                            Text(
                                text = "الفضل: ${item.virtue}",
                                fontSize = 11.sp,
                                lineHeight = 16.sp,
                                color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.9f),
                                fontWeight = FontWeight.Normal
                            )
                        }
                        if (item.reference.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "[ ${item.reference} ]",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                                fontWeight = FontWeight.Light,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Left
                            )
                        }
                    }
                }
            }

            // Simple visual progress bar bottom
            if (!isCompleted && progressFraction > 0f) {
                Spacer(modifier = Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { progressFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(CircleShape),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                )
            }
        }
    }
}

// ----------------------------------------------------
// TAB 2: DIGITAL ELECTRONIC ROSARY (TASBIH)
// ----------------------------------------------------
@OptIn(ExperimentalAnimationApi::class)
@Composable
fun TasbihTabScreen(viewModel: DhikrViewModel, fontSize: Float) {
    val count by viewModel.tasbihCount.collectAsStateWithLifecycle()
    val target by viewModel.tasbihTarget.collectAsStateWithLifecycle()
    val phrase by viewModel.selectedTasbihPhrase.collectAsStateWithLifecycle()
    val customDhikrs by viewModel.customDhikrs.collectAsStateWithLifecycle()

    var showCreateCustomDialog by remember { mutableStateOf(false) }

    val view = LocalView.current
    val soundEnabled by viewModel.isSoundEnabled.collectAsStateWithLifecycle()

    val progress = remember(count, target) {
        if (target > 0) (count % target).toFloat() / target else 0f
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Selection lists
        Text(
            text = "اختر صيغة الذكر أو الاستغفار",
            color = MaterialTheme.colorScheme.secondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Built-in lists
            viewModel.popularTasbihPhrases.forEach { p ->
                val isSel = p == phrase
                FilterChip(
                    selected = isSel,
                    onClick = { viewModel.selectTasbihPhrase(p) },
                    label = { Text(p.take(18) + (if (p.length > 18) ".." else ""), fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                        containerColor = MaterialTheme.colorScheme.surface,
                        labelColor = MaterialTheme.colorScheme.primary
                    )
                )
            }

            // User-added entries
            customDhikrs.forEach { custom ->
                val isSel = custom.text == phrase
                FilterChip(
                    selected = isSel,
                    onClick = { viewModel.selectTasbihPhrase(custom.text) },
                    label = { Text(custom.text.take(18) + (if (custom.text.length > 18) ".." else ""), fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                        containerColor = MaterialTheme.colorScheme.surface,
                        labelColor = MaterialTheme.colorScheme.primary
                    )
                )
            }

            // Special '+' Add Chip
            ActionChip(
                onClick = { showCreateCustomDialog = true },
                label = { Text("+ إضافة ذكر مخصص", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            )
        }

        // Selected phrase display
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "الذِّكْرُ الـمُخْتَار",
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = phrase,
                    fontSize = (fontSize + 1).sp,
                    lineHeight = (fontSize * 1.5).sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Ring progress digital clicker
        val ringColor = MaterialTheme.colorScheme.primary
        Box(
            modifier = Modifier
                .size(240.dp)
                .shadow(16.dp, CircleShape, spotColor = ringColor)
                .clip(CircleShape)
                .clickable {
                    if (soundEnabled) {
                        view.playSoundEffect(android.view.SoundEffectConstants.CLICK)
                    }
                    viewModel.incrementTasbih()
                }
                .drawBehind {
                    // Draw classical subtle golden outer circle ring
                    drawCircle(
                        color = ringColor.copy(alpha = 0.1f),
                        radius = size.width / 2f,
                        style = Stroke(width = 6f)
                    )

                    // Draw dynamic metallic progress ring arc
                    if (target > 0) {
                        drawArc(
                            color = ringColor,
                            startAngle = -90f,
                            sweepAngle = progress * 360f,
                            useCenter = false,
                            style = Stroke(
                                width = 10f,
                                pathEffect = PathEffect.cornerPathEffect(4f)
                            )
                        )
                    }

                    // Geometric Islamic multi-star pattern lines inside the circle beautifully.
                    val numPoints = 8
                    val innerR = size.width * 0.35f
                    val outerR = size.width * 0.45f
                    val center = Offset(size.width / 2, size.height / 2)
                    for (i in 0 until numPoints) {
                        val angle = (i * 2 * Math.PI / numPoints).toFloat()
                        val outerX = center.x + outerR * cos(angle)
                        val outerY = center.y + outerR * sin(angle)
                        val innerX = center.x + innerR * cos(angle + (Math.PI / numPoints).toFloat())
                        val innerY = center.y + innerR * sin(angle + (Math.PI / numPoints).toFloat())
                        drawLine(
                            color = ringColor.copy(alpha = 0.05f),
                            start = center,
                            end = Offset(outerX, outerY),
                            strokeWidth = 1.5f
                        )
                    }
                }
                .testTag("tasbih_circle_tap"),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Taps counter with scaling animation
                AnimatedContent(
                    targetState = count,
                    transitionSpec = {
                        scaleIn(animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)) togetherWith scaleOut()
                    },
                    label = "CounterAnimation"
                ) { targetVal ->
                    Text(
                        text = String.format(Locale.getDefault(), "%d", targetVal),
                        fontSize = 58.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                if (target > 0) {
                    Text(
                        text = "الهدف: $target",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "دورة رقم ${(count / target) + 1}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        fontWeight = FontWeight.Normal
                    )
                } else {
                    Text(
                        text = "نظام حرّ",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Target controllers chips
        Text(
            text = "تحديد هدف التكرار دورياً",
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Absolute.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val targets = listOf(33, 100, 1000, 0)
            targets.forEach { t ->
                val name = if (t == 0) "حرّ" else t.toString()
                val isSel = target == t
                ElevatedFilterChip(
                    selected = isSel,
                    onClick = { viewModel.setTasbihTarget(t) },
                    label = { Text(name) },
                    modifier = Modifier.padding(horizontal = 4.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Reset and decrease buttons
        Row(
            modifier = Modifier.fillMaxWidth(0.85f),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedButton(
                onClick = { viewModel.decrementTasbih() },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("تراجع عن كبسة", fontSize = 12.sp)
            }

            Button(
                onClick = { viewModel.resetTasbih() },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("reset_tasbih_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface)
                Spacer(modifier = Modifier.width(4.dp))
                Text("تصفير العداد", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
            }
        }
    }

    if (showCreateCustomDialog) {
        CreateCustomDhikrDialog(
            onDismiss = { showCreateCustomDialog = false },
            onSave = { text, targetVal ->
                viewModel.addCustomDhikr(text, targetVal)
                showCreateCustomDialog = false
            }
        )
    }
}

// ----------------------------------------------------
// TAB 3: SPIRITUAL HISTORY & PROGRESS STATS
// ----------------------------------------------------
@Composable
fun HistoryTabScreen(viewModel: DhikrViewModel) {
    val historyLogs by viewModel.dhikrHistory.collectAsStateWithLifecycle()
    val todayTotal by viewModel.todayTotalCount.collectAsStateWithLifecycle()
    val dailyGoal by viewModel.dailyGoal.collectAsStateWithLifecycle()

    val progressPercent = remember(todayTotal, dailyGoal) {
        if (dailyGoal > 0) (todayTotal.toFloat() / dailyGoal).coerceIn(0f, 1f) else 1f
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Dashboard circular progress
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "مستوى التزامك وتقدمك اليوم",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(16.dp))

                val progressPrimaryColor = MaterialTheme.colorScheme.primary
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .drawBehind {
                            // Circular background tracks
                            drawCircle(
                                color = progressPrimaryColor.copy(alpha = 0.08f),
                                radius = size.width / 2f,
                                style = Stroke(width = 8f)
                            )
                            // Progress bar
                            drawArc(
                                color = progressPrimaryColor,
                                startAngle = -90f,
                                sweepAngle = progressPercent * 360f,
                                useCenter = false,
                                style = Stroke(width = 8f)
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = String.format(Locale.getDefault(), "%.0f%%", progressPercent * 100),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "من الهدف",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("مجموع أذكارك اليوم", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        Text("$todayTotal ذكراً", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("الهدف اليومي المحدد", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        Text("$dailyGoal ذكراً", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Adjust goals controllers
                Row(
                    modifier = Modifier.fillMaxWidth(0.9f),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("تعديل الهدف اليومي:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.updateDailyGoal(dailyGoal - 100) },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(36.dp),
                            shape = CircleShape
                        ) {
                            Text("-", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }

                        Text("$dailyGoal", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                        OutlinedButton(
                            onClick = { viewModel.updateDailyGoal(dailyGoal + 100) },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(36.dp),
                            shape = CircleShape
                        ) {
                            Text("+", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Action controls for DB
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "سجل الأذكار والعمل الصالح",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary
            )

            TextButton(
                onClick = { viewModel.clearAllHistoryLogs() },
                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) {
                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تصفير السجل", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // History lists display
        if (historyLogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "سجلك فارغ حالياً. ستبدأ الإحصائيات بالتكون تلقائياً بمجرد إكمال أي ذكر أو التسبيح بالسبحة.",
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
            }
        } else {
            // Render last 30 logs in a compact card list
            historyLogs.forEach { log ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = log.arabicText,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = log.dateString,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                            )
                        }

                        // Completed Count badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "+${log.count}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// TAB 4: VIRTUES & BENEFITS OF ISTIGHFAR
// ----------------------------------------------------
@Composable
fun BenefitsTabScreen(fontSize: Float) {
    val context = LocalContext.current
    val benefits = listOf(
        Pair(
            "مغفرة الذنوب وتطهير القمّة",
            "قال الله تعالى في سورة نوح: { فَقُلْتُ اسْتَغْفِرُوا رَبَّكُمْ إِنَّهُ كَانَ غَفَّارًا }. الاستغفار يمحق صغائر الذنوب وكبائرها متى ما اقترن بالصدق والندم."
        ),
        Pair(
            "تنزيل الغيث والموارد المالية والبركة",
            "يقول الله سبحانه: { يُرْسِلِ السَّمَاءَ عَلَيْكُمْ مِدْرَارًا * وَيُمْدِدْكُمْ بِأَمْوَالٍ وَبَنِينَ وَيَجْعَلْ لَكُمْ جَنَّاتٍ وَيَجْعَلْ لَكُمْ أَنْهَارًا }. الاستغفار مفتاح للمال والولد وبركة الرزق."
        ),
        Pair(
            "دفع البلاء والوقاية من العقاب",
            "يقول جل جلاله: { وَمَا كَانَ اللَّهُ لِيُعَذِّبَهُمْ وَأَنْتَ فِيهِمْ وَمَا كَانَ اللَّهُ مُعَذِّبَهُمْ وَهُمْ يَسْتَغْفِرُونَ }. الاستغفار أمان من عذاب الله وبلاء الدنيا الآجل."
        ),
        Pair(
            "الحصول على القوة والطاقة الإيجابية",
            "قال تعالى على لسان هود عليه السلام: { وَيَا قَوْمِ اسْتَغْفِرُوا رَبَّكُمْ ثُمَّ تُوبُوا إِلَيْهِ يُرْسِلِ السَّمَاءَ عَلَيْكُمْ مِدْرَارًا وَيَزِدْكُمْ قُوَّةً إِلَىٰ قُوَّتِكُمْ }."
        ),
        Pair(
            "تفريج الكروب ومغاليق الصدر",
            "عن النبي صلى الله عليه وسلم قال: \"مَنْ لَزِمَ الْاسْتِغْفَارَ جَعَلَ اللَّهُ لَهُ مِنْ كُلِّ ضِيقٍ مَخْرَجًا، وَمِنْ كُلِّ هَمٍّ فَرَجًا، وَرَزَقَهُ مِنْ حَيْثُ لَا يَحْتَسِبُ\"."
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "فَوائِد ثَمَراتِ الِاسْتِغْفَارِ",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "جمعنا لك هنا بعضاً من الآيات الكريمة والأحاديث النبوية الشريفة التي تؤكد أهمية المداومة على الاستغفار في كل الأوقات كمنهج حياة.",
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }

        benefits.forEach { (title, desc) ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = title,
                            fontSize = (fontSize - 2).sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.weight(1f)
                        )

                        // Share action
                        IconButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, title)
                                    putExtra(Intent.EXTRA_TEXT, "*$title*\n\n$desc \n\n[ من تطبيق أذكار واستغفار ]")
                                }
                                context.startActivity(Intent.createChooser(intent, "مشاركة الفائدة عبر"))
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "مشاركة",
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = desc,
                        fontSize = (fontSize - 1).sp,
                        lineHeight = (fontSize * 1.5).sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Right
                    )
                }
            }
        }
    }
}

// ----------------------------------------------------
// CARD DESIGN: USER CUSTOM DHIKR (أذكاري الخاصة)
// ----------------------------------------------------
@Composable
fun CustomDhikrItemCard(custom: CustomDhikr, viewModel: DhikrViewModel, fontSize: Float) {
    var stateCount by remember { mutableStateOf(0) }
    val isCompleted = stateCount >= custom.target
    val view = LocalView.current
    val soundEnabled by viewModel.isSoundEnabled.collectAsStateWithLifecycle()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable {
                if (!isCompleted) {
                    stateCount += 1
                    if (soundEnabled) {
                        view.playSoundEffect(android.view.SoundEffectConstants.CLICK)
                    }
                    if (stateCount == custom.target) {
                        // Log full completed session
                        viewModel.addCustomDhikr(custom.text, custom.target)
                    }
                }
            },
        colors = CardDefaults.cardColors(
            containerColor = if (isCompleted) MaterialTheme.colorScheme.surface.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            1.dp,
            if (isCompleted) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.4f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (isCompleted) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(16.dp))
                        Text("مكتمل بفضل الله", fontSize = 11.sp, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
                    } else {
                        val remaining = custom.target - stateCount
                        Text("متبقي: $remaining / ${custom.target}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }

                // Delete custom item
                IconButton(
                    onClick = { viewModel.deleteCustomDhikr(custom.id) },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "حذف الذكر المخصص",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = custom.text,
                fontSize = fontSize.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Right,
                color = if (isCompleted) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f) else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ----------------------------------------------------
// DIALOG DESIGN: APP SETTINGS (إعدادات التطبيق)
// ----------------------------------------------------
@Composable
fun SettingsDialog(
    viewModel: DhikrViewModel,
    currentFontSize: Float,
    isSound: Boolean,
    isVibe: Boolean,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "إعدادات التطبيق",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Slider font
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("حجم خط الأذكار العربي:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("${currentFontSize.toInt()} dp", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = currentFontSize,
                        onValueChange = { viewModel.setFontSize(it) },
                        valueRange = 14f..28f,
                        steps = 7,
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Toggle Sound
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("تشغيل صوت النقر التفاعلي", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Switch(
                        checked = isSound,
                        onCheckedChange = { viewModel.toggleSound(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.primary)
                    )
                }

                // Toggle Vibration
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("تشغيل الهزاز اللمسي الذكي", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Switch(
                        checked = isVibe,
                        onCheckedChange = { viewModel.toggleVibration(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.primary)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Dismiss Button
                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("dismiss_settings_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("إغلاق وحفظ الـتعديلات", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ----------------------------------------------------
// DIALOG DESIGN: CREATE SMART CUSTOM DHIKR
// ----------------------------------------------------
@Composable
fun CreateCustomDhikrDialog(
    onDismiss: () -> Unit,
    onSave: (text: String, target: Int) -> Unit
) {
    var text by remember { mutableStateOf("") }
    var targetStr by remember { mutableStateOf("100") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "إضافة ذكر أو استغفار مخصص",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("نص الذكر المقترح...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_dhikr_text_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = targetStr,
                    onValueChange = { targetStr = it.filter { ch -> ch.isDigit() } },
                    label = { Text("تحديد الهدف (مثال: 33, 100, 1000)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_dhikr_target_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إلغاء الأمر")
                    }

                    Button(
                        onClick = {
                            val targetVal = targetStr.toIntOrNull() ?: 100
                            onSave(text, targetVal)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("save_custom_dhikr_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إضافة وحفظ")
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// GENERIC CHIP ACTIONS COMPONENT
// ----------------------------------------------------
@Composable
fun ActionChip(
    onClick: () -> Unit,
    label: @Composable () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier
            .padding(vertical = 4.dp)
            .height(32.dp),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
        contentColor = MaterialTheme.colorScheme.primary,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            label()
        }
    }
}
