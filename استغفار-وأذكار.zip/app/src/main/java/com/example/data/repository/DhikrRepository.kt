package com.example.data.repository

import com.example.data.db.DhikrDao
import com.example.data.model.CustomDhikr
import com.example.data.model.DhikrHistory
import kotlinx.coroutines.flow.Flow

class DhikrRepository(private val dhikrDao: DhikrDao) {

    val allCustomDhikrs: Flow<List<CustomDhikr>> = dhikrDao.getAllCustomDhikrs()
    val allHistory: Flow<List<DhikrHistory>> = dhikrDao.getAllHistory()

    suspend fun insertCustomDhikr(customDhikr: CustomDhikr) {
        dhikrDao.insertCustomDhikr(customDhikr)
    }

    suspend fun deleteCustomDhikrById(id: Int) {
        dhikrDao.deleteCustomDhikrById(id)
    }

    suspend fun addCompletedSession(dateString: String, dhikrKey: String, arabicText: String, addCount: Int) {
        val existing = dhikrDao.getHistoryItem(dateString, dhikrKey)
        if (existing != null) {
            val updated = existing.copy(
                count = existing.count + addCount,
                timestamp = System.currentTimeMillis()
            )
            dhikrDao.insertHistory(updated)
        } else {
            val newHistory = DhikrHistory(
                dateString = dateString,
                dhikrKey = dhikrKey,
                arabicText = arabicText,
                count = addCount
            )
            dhikrDao.insertHistory(newHistory)
        }
    }

    suspend fun clearHistory() {
        dhikrDao.clearAllHistory()
    }
}
