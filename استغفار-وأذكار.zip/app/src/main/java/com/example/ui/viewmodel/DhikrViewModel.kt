package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.runtime.mutableStateMapOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.DhikrDatabase
import com.example.data.model.CustomDhikr
import com.example.data.model.DhikrHistory
import com.example.data.repository.DhikrRepository
import com.example.ui.model.DhikrStaticItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class MainTab {
    AZKAR,      // الأذكار اليومية
    TASBIH,     // السبحة الإلكترونية
    HISTORY,    // السجل والإحصائيات
    BENEFITS    // فضائل الاستغفار
}

class DhikrViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: DhikrRepository

    // Settings States
    private val _fontSizeFlow = MutableStateFlow(18f) // Dynamic Font Size for Dhikr Text
    val fontSizeFlow: StateFlow<Float> = _fontSizeFlow.asStateFlow()

    private val _isVibrationEnabled = MutableStateFlow(true)
    val isVibrationEnabled: StateFlow<Boolean> = _isVibrationEnabled.asStateFlow()

    private val _isSoundEnabled = MutableStateFlow(true)
    val isSoundEnabled: StateFlow<Boolean> = _isSoundEnabled.asStateFlow()

    // Screen navigation
    private val _currentTab = MutableStateFlow(MainTab.AZKAR)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    // Room Database states
    val customDhikrs: StateFlow<List<CustomDhikr>>
    val dhikrHistory: StateFlow<List<DhikrHistory>>

    // Today's total count of Tasbih
    private val _todayTotalCount = MutableStateFlow(0)
    val todayTotalCount: StateFlow<Int> = _todayTotalCount.asStateFlow()

    // Daily spiritual goal
    private val _dailyGoal = MutableStateFlow(100)
    val dailyGoal: StateFlow<Int> = _dailyGoal.asStateFlow()

    // Session-based remaining counts for standard Azkar list (so user can tap to count down 3, 2, 1, Done)
    // Map with Key: StaticDhikr.id -> Remaining Count
    val staticDhikrProgress = mutableStateMapOf<String, Int>()

    // Digital Tasbih (السبحة الإلكترونية) State
    private val _tasbihCount = MutableStateFlow(0)
    val tasbihCount: StateFlow<Int> = _tasbihCount.asStateFlow()

    private val _tasbihTarget = MutableStateFlow(33) // e.g. 33, 100, 1000, 0 for open ended
    val tasbihTarget: StateFlow<Int> = _tasbihTarget.asStateFlow()

    // Prepopulated popular tasbih expressions (أذكار وعبارات للسبحة)
    val popularTasbihPhrases = listOf(
        "أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ وَأَتُوبُ إِلَيْهِ",
        "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
        "سُبْحَانَ اللَّهِ الْعَظِيمِ",
        "الْحَمْدُ لِلَّهِ حَمْدًا كَثِيرًا",
        "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ",
        "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
        "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ",
        "سُبْحَانَ اللَّهِ ، وَالْحَمْدُ لِلَّهِ ، وَلَا إِلَهَ إِلَّا اللَّهُ ، وَاللَّهُ أَكْبَرُ"
    )

    private val _selectedTasbihPhrase = MutableStateFlow("أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ وَأَتُوبُ إِلَيْهِ")
    val selectedTasbihPhrase: StateFlow<String> = _selectedTasbihPhrase.asStateFlow()

    init {
        val database = DhikrDatabase.getDatabase(application)
        repository = DhikrRepository(database.dhikrDao())

        customDhikrs = repository.allCustomDhikrs.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dhikrHistory = repository.allHistory.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Calculate today's total across all history entries when history state flows
        viewModelScope.launch {
            dhikrHistory.collect { list ->
                val today = getTodayDateString()
                val todayCount = list.filter { it.dateString == today }.sumOf { it.count }
                _todayTotalCount.value = todayCount
            }
        }
    }

    // Navigation and screen utilities
    fun switchTab(tab: MainTab) {
        _currentTab.value = tab
    }

    // Static Dhikr decrementer (taping in the card)
    fun decrementStaticDhikr(item: DhikrStaticItem) {
        val currentRemaining = staticDhikrProgress[item.id] ?: item.count
        if (currentRemaining > 0) {
            val next = currentRemaining - 1
            staticDhikrProgress[item.id] = next

            triggerHapticFeedback()

            // When exactly completed, log to Room DB history!
            if (next == 0) {
                logHistoryCount(
                    dhikrKey = item.id,
                    arabicText = item.text.take(60) + "...",
                    count = item.count
                )
            }
        }
    }

    // Reset progress for specific category or specific item
    fun resetStaticDhikr(item: DhikrStaticItem) {
        staticDhikrProgress[item.id] = item.count
    }

    fun resetCategoryProgress(categoryItems: List<DhikrStaticItem>) {
        categoryItems.forEach { item ->
            staticDhikrProgress[item.id] = item.count
        }
    }

    // Digital Tasbih Screen Controls
    fun incrementTasbih() {
        val newCount = _tasbihCount.value + 1
        _tasbihCount.value = newCount
        triggerHapticFeedback()

        // Real-time logging of each single count to Day History to keep stats absolutely real and persistent!
        logHistoryCount(
            dhikrKey = "tasbih_manual",
            arabicText = _selectedTasbihPhrase.value,
            count = 1
        )

        val target = _tasbihTarget.value
        // If we hit target (and target != 0 which is unlimited), trigger a long vibration alert or special audio trigger
        if (target > 0 && newCount % target == 0) {
            triggerVibrationAlert()
        }
    }

    fun decrementTasbih() {
        if (_tasbihCount.value > 0) {
            _tasbihCount.value -= 1
            logHistoryCount(
                dhikrKey = "tasbih_manual",
                arabicText = _selectedTasbihPhrase.value,
                count = -1
            )
        }
    }

    fun resetTasbih() {
        _tasbihCount.value = 0
    }

    fun selectTasbihPhrase(phrase: String) {
        _selectedTasbihPhrase.value = phrase
        resetTasbih()
    }

    fun setTasbihTarget(target: Int) {
        _tasbihTarget.value = target
        resetTasbih()
    }

    // Custom Dhikr entries (الذكر المخصص)
    fun addCustomDhikr(text: String, target: Int) {
        viewModelScope.launch {
            if (text.isNotBlank()) {
                repository.insertCustomDhikr(CustomDhikr(text = text, target = target))
            }
        }
    }

    fun deleteCustomDhikr(id: Int) {
        viewModelScope.launch {
            repository.deleteCustomDhikrById(id)
        }
    }

    // Settings actions
    fun setFontSize(size: Float) {
        _fontSizeFlow.value = size
    }

    fun toggleVibration(enabled: Boolean) {
        _isVibrationEnabled.value = enabled
    }

    fun toggleSound(enabled: Boolean) {
        _isSoundEnabled.value = enabled
    }

    fun updateDailyGoal(goal: Int) {
        if (goal > 0) {
            _dailyGoal.value = goal
        }
    }

    fun clearAllHistoryLogs() {
        viewModelScope.launch {
            repository.clearHistory()
            _todayTotalCount.value = 0
        }
    }

    // Private db logger helper
    private fun logHistoryCount(dhikrKey: String, arabicText: String, count: Int) {
        viewModelScope.launch {
            val todayStr = getTodayDateString()
            repository.addCompletedSession(
                dateString = todayStr,
                dhikrKey = dhikrKey,
                arabicText = arabicText,
                addCount = count
            )
        }
    }

    // Date String generator
    private fun getTodayDateString(): String {
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return formatter.format(Date())
    }

    // Haptics & Feedback Implementation
    private fun triggerHapticFeedback() {
        if (!_isVibrationEnabled.value) return
        val context = getApplication<Application>().applicationContext
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

        vibrator?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                it.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                it.vibrate(35)
            }
        }
    }

    private fun triggerVibrationAlert() {
        if (!_isVibrationEnabled.value) return
        val context = getApplication<Application>().applicationContext
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

        vibrator?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Two pulse vibration when cycle finishes
                val pattern = longArrayOf(0, 150, 100, 150)
                it.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                it.vibrate(300)
            }
        }
    }
}
