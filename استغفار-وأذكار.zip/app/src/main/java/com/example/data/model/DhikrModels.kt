package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "dhikr_history")
data class DhikrHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val dateString: String, // format: "yyyy-MM-dd"
    val dhikrKey: String,   // standard or custom category key
    val arabicText: String,
    val count: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "custom_dhikr")
data class CustomDhikr(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val text: String,
    val target: Int,
    val timestamp: Long = System.currentTimeMillis()
)
