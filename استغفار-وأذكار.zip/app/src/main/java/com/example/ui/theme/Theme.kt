package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = ElegantActiveHighlight,
    onPrimary = ElegantSecondaryBadge,
    secondary = ElegantSoftBlue,
    onSecondary = ElegantLightText,
    tertiary = ElegantAccentGrey,
    background = ElegantDarkBg,
    onBackground = ElegantLightText,
    surface = ElegantSurface,
    onSurface = ElegantLightText,
    surfaceVariant = ElegantBorder,
    onSurfaceVariant = ElegantLightText,
    error = ElegantActiveHighlight
)

private val LightColorScheme = lightColorScheme(
    primary = DeepGreenPrimary,
    onPrimary = ElegantPureWhite,
    secondary = ElegantSecondaryBadge,
    onSecondary = ElegantLightText,
    tertiary = ElegantBorder,
    background = CreamLightBackground,
    onBackground = DeepGreenText,
    surface = GoldBeigeContainer,
    onSurface = DeepGreenText,
    surfaceVariant = GoldBeigeContainer,
    onSurfaceVariant = DeepGreenText,
    error = ElegantActiveHighlight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Preserve our custom curated design branding
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
