package com.example.ui.model

data class DhikrStaticItem(
    val id: String,
    val category: DhikrCategory,
    val text: String,
    val count: Int, // recommended repetitions
    val virtue: String, // what it brings the Muslim
    val reference: String = "" // source, e.g., "رواه البخاري"
)

enum class DhikrCategory(val arabicName: String) {
    MORNING("أذكار الصباح"),
    EVENING("أذكار المساء"),
    POST_PRAYER("بعد الصلاة"),
    ISTIGHFAR_TASBIH("استغفار وتسبيح")
}

object DhikrData {
    val items = listOf(
        // MORNING
        DhikrStaticItem(
            id = "m_ayat_kursi",
            category = DhikrCategory.MORNING,
            text = "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۚ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ",
            count = 1,
            virtue = "من قالها حين يصبح أجير من الجن حتى يمسي، ومن قالها حين يمسي أجير منهم حتى يصبح.",
            reference = "رواه الحاكم"
        ),
        DhikrStaticItem(
            id = "m_ikhlas_muawidhat",
            category = DhikrCategory.MORNING,
            text = "قُلْ هُوَ اللَّهُ أَحَدٌ... قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ... قُلْ أَعُوذُ بِرَبِّ النَّاسِ...",
            count = 3,
            virtue = "تكفيك من كل شيء إذا قرأتها ثلاثاً في الصباح والمساء.",
            reference = "رواه الترمذي"
        ),
        DhikrStaticItem(
            id = "m_sayyid_istighfar",
            category = DhikrCategory.MORNING,
            text = "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ.",
            count = 1,
            virtue = "سيد الاستغفار: من قالها موقناً بها ومات في يومه قبل أن يمسي دخل الجنة.",
            reference = "رواه البخاري"
        ),
        DhikrStaticItem(
            id = "m_raddit",
            category = DhikrCategory.MORNING,
            text = "رَضِيتُ بِاللهِ رَبًّا، وَبِالإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا.",
            count = 3,
            virtue = "من قالها ثلاثاً في الصباح والمساء كان حقاً على الله أن يرضيه يوم القيامة.",
            reference = "رواه أحمد"
        ),
        DhikrStaticItem(
            id = "m_bismillah_fala_yadurr",
            category = DhikrCategory.MORNING,
            text = "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ.",
            count = 3,
            virtue = "من قالها ثلاثاً لم يضره شيء في يومه وليلتة.",
            reference = "رواه أبو داود"
        ),

        // EVENING (similarly structured and beautiful)
        DhikrStaticItem(
            id = "e_ayat_kursi",
            category = DhikrCategory.EVENING,
            text = "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۚ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ",
            count = 1,
            virtue = "أجير من الجن والهموم حتى يصبح.",
            reference = "رواه الحاكم"
        ),
        DhikrStaticItem(
            id = "e_sayyid_istighfar",
            category = DhikrCategory.EVENING,
            text = "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ.",
            count = 1,
            virtue = "سيد الاستغفار: إذا مات ليلتها دخل الجنة.",
            reference = "رواه البخاري"
        ),
        DhikrStaticItem(
            id = "e_amshayna",
            category = DhikrCategory.EVENING,
            text = "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ للهِ، وَالْحَمْدُ للهِ، لَا إِلَهَ إِلَّا اللهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.",
            count = 1,
            virtue = "سؤال خير هذه الليلة والتعوذ من شرها وشر ما بعدها.",
            reference = "رواه مسلم"
        ),
        DhikrStaticItem(
            id = "e_a_udhu_bikalimat",
            category = DhikrCategory.EVENING,
            text = "أَعُوذُ بِكَلِمَاتِ اللهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ.",
            count = 3,
            virtue = "لم تضره لدغة عقرب أو حية أو أي شر في هذه الليلة.",
            reference = "رواه مسلم"
        ),

        // POST_PRAYER (بعد الصلاة المفروضة)
        DhikrStaticItem(
            id = "p_astaghfir",
            category = DhikrCategory.POST_PRAYER,
            text = "أَسْتَغْفِرُ اللهَ (ثلاثًا) .. اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ.",
            count = 1,
            virtue = "الاستفتاح النبوي دبر كل صلاة مكتوبة لتغطية أي خلل في الصلاة.",
            reference = "رواه مسلم"
        ),
        DhikrStaticItem(
            id = "p_tasbih",
            category = DhikrCategory.POST_PRAYER,
            text = "سُبْحَانَ اللهِ (33 مرة) - الْحَمْدُ للهِ (33 مرة) - اللهُ أَكْبَرُ (33 مرة)",
            count = 99,
            virtue = "من قالها دبر كل صلاة ثم تمم المائة بـ (لا إله إلا الله..) غفرت خطاياه وإن كانت مثل زبد البحر.",
            reference = "رواه مسلم"
        ),
        DhikrStaticItem(
            id = "p_ayat_kursi",
            category = DhikrCategory.POST_PRAYER,
            text = "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ (آية الكرسي دبر كل صلاة)",
            count = 1,
            virtue = "من قرأها دبر كل صلاة مكتوبة لم يمنعه من دخول الجنة إلا أن يموت.",
            reference = "رواه النسائي"
        ),

        // ISTIGHFAR & TASBIH (الاستغفار والتسبيح)
        DhikrStaticItem(
            id = "istighfar_100",
            category = DhikrCategory.ISTIGHFAR_TASBIH,
            text = "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ.",
            count = 100,
            virtue = "توسيع في الرزق، والفرج من المآزق والهموم، وقرب العبد من ربه الكريم.",
            reference = "رواه البخاري ومسلم"
        ),
        DhikrStaticItem(
            id = "hawqala",
            category = DhikrCategory.ISTIGHFAR_TASBIH,
            text = "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ العَلِيِّ العَظِيمِ.",
            count = 100,
            virtue = "كنز عظيم من كنوز الجنة، وباب عظيم للمدد والتيسير ودفع الشدائد والمشاق.",
            reference = "متفق عليه"
        ),
        DhikrStaticItem(
            id = "salat_nabiyy",
            category = DhikrCategory.ISTIGHFAR_TASBIH,
            text = "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ.",
            count = 100,
            virtue = "كفاية للهموم والغموم، وغفران عظيم للذنوب، ومن صلى عليه واحدة صلى الله بها عليه عشراً.",
            reference = "رواه الترمذي"
        ),
        DhikrStaticItem(
            id = "subhan_allah_bihamdihi",
            category = DhikrCategory.ISTIGHFAR_TASBIH,
            text = "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ ، سُبْحَانَ اللَّهِ العَظِيمِ.",
            count = 100,
            virtue = "كلمتان خفيفتان على اللسان، ثقيلتان في الميزان، حبيبتان إلى الرحمن.",
            reference = "رواه البخاري"
        ),
        DhikrStaticItem(
            id = "tahlil",
            category = DhikrCategory.ISTIGHFAR_TASBIH,
            text = "لَا إِلَهَ إِلَّا اللهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.",
            count = 100,
            virtue = "كانت له عدل عشر رقاب، وكتبت له مئة حسنة، ومحيت عنه مئة سيئة، وحرز من الشيطان.",
            reference = "رواه البخاري ومسلم"
        )
    )
}
