package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.CustomDhikr
import com.example.data.model.DhikrHistory

@Database(entities = [CustomDhikr::class, DhikrHistory::class], version = 1, exportSchema = false)
abstract class DhikrDatabase : RoomDatabase() {
    abstract fun dhikrDao(): DhikrDao

    companion object {
        @Volatile
        private var INSTANCE: DhikrDatabase? = null

        fun getDatabase(context: Context): DhikrDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DhikrDatabase::class.java,
                    "dhikr_database_v1"
                )
                .fallbackToDestructiveMigration(true)
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
