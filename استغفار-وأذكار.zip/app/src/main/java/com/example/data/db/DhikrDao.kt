package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.CustomDhikr
import com.example.data.model.DhikrHistory
import kotlinx.coroutines.flow.Flow

@Dao
interface DhikrDao {
    @Query("SELECT * FROM custom_dhikr ORDER BY timestamp DESC")
    fun getAllCustomDhikrs(): Flow<List<CustomDhikr>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomDhikr(customDhikr: CustomDhikr)

    @Query("DELETE FROM custom_dhikr WHERE id = :id")
    suspend fun deleteCustomDhikrById(id: Int)

    @Query("SELECT * FROM dhikr_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<DhikrHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: DhikrHistory)

    @Query("SELECT * FROM dhikr_history WHERE dateString = :dateString AND dhikrKey = :dhikrKey LIMIT 1")
    suspend fun getHistoryItem(dateString: String, dhikrKey: String): DhikrHistory?

    @Query("DELETE FROM dhikr_history")
    suspend fun clearAllHistory()
}
