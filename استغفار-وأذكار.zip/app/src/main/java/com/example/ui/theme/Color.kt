package com.example.ui.theme

import androidx.compose.ui.graphics.Color
// Elegant Dark Design Theme colors
val ElegantDarkBg = Color(0xFF0F1113)         // Soft slate deep dark background
val ElegantSurface = Color(0xFF1A1C1E)        // App cards/surfaces background
val ElegantBorder = Color(0xFF2D2F31)         // Subtle border / divider stroke
val ElegantActiveHighlight = Color(0xFFD0BCFF) // Beautiful glowing violet/purple active highlight
val ElegantSecondaryBadge = Color(0xFF381E72)  // Soft dark violet badge container
val ElegantSoftBlue = Color(0xFFA8C8FB)        // Creative secondary blue details & titles
val ElegantMutedText = Color(0xFF909194)       // Clean dark gray descriptions and references
val ElegantAccentGrey = Color(0xFF3F474E)      // Dynamic sub-button/avatar surface
val ElegantLightText = Color(0xFFE2E2E6)       // White slate text
val ElegantPureWhite = Color(0xFFFFFFFF)       // Pure white

// Light Mode Counterparts
val CreamLightBackground = Color(0xFFFAF8F4)
val DeepGreenPrimary = Color(0xFF153F32)
val GoldBeigeContainer = Color(0xFFEFECE5)
val DeepGreenText = Color(0xFF112B22)
